// src/names.js
export const NAMES = [
    "John","David","Jane","Amy","Michael","Sarah","Robert","Jessica","William","Emily",
    "James","Emma","Charles","Olivia","Daniel","Sophia","Matthew","Isabella","Joseph","Mia",
    "Anthony","Charlotte","Mark","Amelia","Paul","Evelyn","Steven","Abigail","Andrew","Harper",
    "Joshua","Emily","Kenneth","Elizabeth","Kevin","Avery","Brian","Sofia","George","Ella",
    "Edward","Madison","Ronald","Scarlett","Timothy","Victoria","Jason","Grace","Jeffrey","Chloe",
    "Ryan","Camila","Jacob","Penelope","Gary","Riley","Nicholas","Layla","Eric","Lillian",
    "Jonathan","Zoey","Stephen","Nora","Larry","Lily","Justin","Eleanor","Scott","Hannah",
    "Brandon","Luna","Benjamin","Hazel","Samuel","Aria","Gregory","Aurora","Frank","Violet",
    "Patrick","Nova","Raymond","Emilia","Jack","Stella","Dennis","Zoe","Jerry","Paisley",
    "Tyler","Anna","Aaron","Maya","Henry","Scarlett","Douglas","Willow","Peter","Brooklyn",
    "Zachary","Leah","Kyle","Lucy","Walter","Savannah","Harold","Audrey","Jeremy","Claire",
    "Ethan","Skylar","Carl","Genesis","Arthur","Brielle","Lawrence","Anna","Christian","Allison",
    "Arthur","Alexandra","Bruce","Claire","Philip","Lucy","Bruce","Natalie","Roger","Violet",
    "Keith","Penelope","Terry","Aurora","Gerald","Anna","Jack","Lillian","Clarence","Mila",
    "Sean","Elena","Albert","Nina","Joe","Ruby","Willie","Serenity","Billy","Autumn",
    "Jordan","Peyton","Albert","Melanie","Dylan","Naomi","Bruce","Sadie","Gabriel","Eva",
    "Logan","Isla","Alan","Ellie","Juan","Anna","Wayne","Lydia","Roy","Rylee",
    "Ralph","Madelyn","Randy","Clara","Eugene","Vivian","Vincent","Marley","Russell","Vivienne",
    "Bobby","Valentina","Philip","Hadley","Johnny","Eliza","Bradley","Cora","Barry","Adeline"
  ];
  


